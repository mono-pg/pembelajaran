import dosen_login from "../models/dosen_login.js";
import siswa_login from "../models/siswa_login.js";

const getLogin = (req,res) => {
    res.render('login',{user : req.session.user || ""})
}

const postLogin = (req,res) => {
    const {email,password} = req.body
    dosen_login.findOne({
        where : {
            email : email
        }
    }).then(result => {
        if(!result){
            siswa_login.findOne({where : {email:email}}).then(result => {
                if (!result) {
                    req.session.err = 'Incorrect email or password.';
                    res.redirect('/login')
                }
                else if (password != result.password) {
                    req.session.err = 'Incorrect password.';
                    res.redirect('/login')
                }
                else {
                    req.session.user = result;
                    res.redirect('/')
                }
            }).catch(err => {
                console.log(err)
            })
        }else{
            if(result.password == password){
                req.session.admin = result
                res.redirect('/')
            }else {
                res.redirect('/login')
            }
        }
    })
}


const logout = (req, res) => {
    req.session.destroy()
    res.redirect('/login')
}
export {
    getLogin,postLogin,logout
}
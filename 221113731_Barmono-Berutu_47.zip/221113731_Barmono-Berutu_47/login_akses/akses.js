

const akses = (req,res,next) => {
    const user = req.session.user || "";
    const admin = req.session.admin || "";

    if(user){
        next()
    }else if(admin){
        next("route")
    }else {
        res.redirect("/login")
    }
}

export default akses
import { sequelize,DataTypes } from "../db/db.js";


const dosen_login = sequelize.define('dosen_logins',{
    email : DataTypes.STRING,
    password : DataTypes.STRING,
})

export default dosen_login;
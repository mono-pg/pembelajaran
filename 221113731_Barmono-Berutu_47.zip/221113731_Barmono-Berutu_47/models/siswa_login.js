import { sequelize,DataTypes } from "../db/db.js";


const siswa_login = sequelize.define('siswa_logins',{
    email : DataTypes.STRING,
    password : DataTypes.STRING,
    no_hp : DataTypes.STRING,
})

export default siswa_login;
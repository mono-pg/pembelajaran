import express from "express"
import siswa from "./models/siswa.js"
import { sequelize } from "./db/db.js"
import akses from "./login_akses/akses.js"
import siswa_login from "./models/siswa_login.js"
import session from "express-session"
import { getLogin, logout, postLogin } from "./login_akses/auth.js"

const app = express()

app.use(express.json())
app.use(express.urlencoded({ extended:true}))
app.set('view engine', 'ejs')

app.use(session({
    secret: 'sadasdjj',
    resave: false,
    saveUninitialized: false,
    cookie: {maxAge: 24 * 60 * 60 * 1000 }
}))

app.get("/login",getLogin)
app.post("/login",postLogin)
app.get("/logout",logout)

app.get('/',akses, (req, res) => {
    siswa.findAll().then(result => {
        res.render('user/index', {data : result,user: req.session.user || ""})
    })
})
app.get('/', (req, res) => {
    siswa_login.findAll().then(result => {
        res.render('admin/index', {data : result,admin: req.session.admin || ""})
    })
})

app.get("/tambah",akses,(req,res) => {
   res.render('tambah')
})

app.post("/tambah",akses,(req,res) => {
    const {nama,nim,alamat} = req.body
    siswa.create({nama,nim,alamat}).then(() => {
        res.redirect("/")
    })
})

app.get("/edit/:id",akses,(req,res) => {
    const id = req.params.id
    siswa.findByPk(id).then(result => {
        res.render('edit', {data : result})
    })
})

app.put("/edit/:id",akses,(req,res) => {
    const id = req.params.id
    const {nama,nim,alamat} = req.body
    siswa.update({nama,nim,alamat},{where:{id}}).then(() => {
        res.sendStatus(200)
    })
})

app.delete("/hapus/:id",akses,(req,res) => {
    const id = req.params.id
    siswa.destroy({where:{id}}).then(() => {
        res.redirect("/")
    })
})
app.delete("/hapus_user/:id",(req,res) => {
    const id = req.params.id
    siswa_login.destroy({where:{id}}).then(() => {
        res.redirect("/")
    })
})


// registrasi
app.get('/register', (req,res) => {
    res.render('register')
})

app.post('/register', (req,res) => {
    const {email,no_hp,password,kpassword} = req.body
    if(password !== kpassword){
        res.redirect('/register')
    }
    siswa_login.create({email,no_hp,password}).then(() => {
        res.redirect("/login")
    }).catch(err => {
        console.log(err)
    })
})

app.listen(3000, async () => {
    try {
        await sequelize.authenticate()
        console.log("berhasil terhubung ke database")
    } catch (error) {
        console.log(error)
    }
    console.log("Server running on port 3000")
})
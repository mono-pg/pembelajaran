import { Sequelize,DataTypes } from "sequelize";

const sequelize = new Sequelize("kampus","root","", {
    host: "localhost",
    dialect: "mysql",  
});

export {sequelize,DataTypes}